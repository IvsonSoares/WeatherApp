import React from 'react';

export default function Hello() {

    return (
        <h1>Hello World</h1>
    )

}